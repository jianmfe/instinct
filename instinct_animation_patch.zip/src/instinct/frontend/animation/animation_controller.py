from dataclasses import dataclass

from instinct.frontend.animation.animation_state import AnimationState
from instinct.frontend.animation.animation_state_machine import (
    AnimationStateMachine,
)
from instinct.frontend.animation.animations_config import AnimationConfig


@dataclass(slots=True)
class CreatureAnimation:
    creature: object
    state_machine: AnimationStateMachine
    frame_index: int = 0
    elapsed_ms: float = 0.0
    finished: bool = False


class AnimationController:
    """Administra una FSM y un reproductor por instancia de criatura."""

    def __init__(self, config=AnimationConfig):
        self.config = config
        self._creatures = {}

    @staticmethod
    def _key(creature):
        return id(creature)

    def _get_or_create(self, creature):
        key = self._key(creature)
        record = self._creatures.get(key)
        if record is None or record.creature is not creature:
            record = CreatureAnimation(
                creature=creature,
                state_machine=AnimationStateMachine(),
            )
            self._creatures[key] = record
        return record

    def set_state(self, creature, state, force=False):
        """Activa un estado y reinicia su reproducción si corresponde."""

        if isinstance(state, str):
            state = AnimationState(state.lower())

        record = self._get_or_create(creature)
        changed = record.state_machine.transition(state, force=force)

        if changed:
            record.frame_index = 0
            record.elapsed_ms = 0.0
            record.finished = False
        return changed

    def get_state(self, creature):
        return self._get_or_create(creature).state_machine.current_state

    def get_frame(self, creature):
        return self._get_or_create(creature).frame_index

    def get_definition(self, creature, state=None):
        record = self._get_or_create(creature)
        state = state or record.state_machine.current_state
        return self.config.get(creature.name, state)

    def update(self, delta_time):
        """Avanza todos los reproductores usando delta_time en segundos."""

        if delta_time < 0:
            raise ValueError("El tiempo transcurrido no puede ser negativo.")

        delta_ms = delta_time * 1000.0

        for record in tuple(self._creatures.values()):
            state = record.state_machine.current_state
            definition = self.config.get(record.creature.name, state)

            if record.finished:
                continue

            record.elapsed_ms += delta_ms

            while record.elapsed_ms >= definition.frame_duration:
                record.elapsed_ms -= definition.frame_duration

                if record.frame_index + 1 < definition.frame_count:
                    record.frame_index += 1
                    continue

                if definition.loop:
                    record.frame_index = 0
                    continue

                if state is AnimationState.DEATH:
                    record.frame_index = definition.frame_count - 1
                    record.finished = True
                else:
                    record.state_machine.finish_animation()
                    record.frame_index = 0
                    record.elapsed_ms = 0.0
                break

    def iter_death_animations(self):
        """Devuelve las criaturas cuya animación de muerte sigue pendiente."""

        for record in tuple(self._creatures.values()):
            if record.state_machine.is_dead:
                yield record.creature, record.frame_index, record.finished

    def remove_creature(self, creature):
        self._creatures.pop(self._key(creature), None)

    def prune(self, living_creatures):
        """Libera registros de criaturas vivas que ya no están en el mundo.

        Las criaturas en DEATH se conservan para poder dibujar su animación.
        """
        living_ids = {id(creature) for creature in living_creatures}
        for key, record in tuple(self._creatures.items()):
            if key not in living_ids and not record.state_machine.is_dead:
                self._creatures.pop(key, None)
